# coding: utf-8

from __future__ import absolute_import

from swagger_server.models.pas import Pas
from . import BaseTestCase
from six import BytesIO
from flask import json


class TestPersonalDeAdministracinYServiciosController(BaseTestCase):
    """ PersonalDeAdministracinYServiciosController integration test stubs """

    def test_crear_pas(self):
        """
        Test case for crear_pas

        Crear un personal
        """
        pas = Pas()
        response = self.client.open('/Pas/PAS/{idPas}',
                                    method='POST',
                                    data=json.dumps(pas),
                                    content_type='application/json')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_get_pas(self):
        """
        Test case for get_pas

        Obtener un Personal de Administración y Servicios en concreto
        """
        response = self.client.open('/Pas/PAS/{idPas}'.format(idPas=56),
                                    method='GET',
                                    content_type='application/json')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
