import connexion
from swagger_server.models.departamento_pas import DepartamentoPas
from datetime import date, datetime
from typing import List, Dict
from six import iteritems
from ..util import deserialize_date, deserialize_datetime
import psycopg2
import json


def busqueda_departamento_pas(idDepartamento):
    """
    Mostrar un deparatamento en concreto
    Buscar un departamento dentro de la lista de departamentos del personal
    :param idDepartamento: Identificador del Departamento del Personal
    :type idDepartamento: int

    :rtype: DepartamentoPas
    """
    conn_string = "host='localhost' dbname='DepartamentoPas' user='ISA' password='1234'"
    
    # get a connection, if a connect cannot be made an exception will be raised here
    conn = psycopg2.connect(conn_string)
    
    # conn.cursor will return a cursor object, you can use this cursor to perform queries
    cursor = conn.cursor()
    
    # execute our Query
    cursor.execute("SELECT * FROM \"departamentoPAS\" WHERE \"id_departamentoPAS\" = " + str(idDepartamento) + ";")
    
    # retrieve the records from the database
    records = cursor.fetchall()
    conn.close()
    return json.dumps(records)


def insertar_departamento_pas(departamento):
    """
    Añadir un nuevo departamento
    Insertar un nuevo departamento en  lista de departamentos del personal
    :param departamento: 
    :type departamento: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        departamento = DepartamentoPas.from_dict(connexion.request.get_json())
    
    conn_string = "host='localhost' dbname='DepartamentoPas' user='ISA' password='1234'"
    # get a connection, if a connect cannot be made an exception will be raised here
    conn = psycopg2.connect(conn_string)
    # conn.cursor will return a cursor object, you can use this cursor to perform queries
    cursor = conn.cursor()

    # execute our Query
    cursor.execute("INSERT INTO \"departamentoPAS\" VALUES (" + repr(departamento.id_departamento) + ",'" + departamento.nombre +                      "','" + departamento.descripcion + "'," + repr(departamento.id_facultad) + ")")
    
    conn.commit()
    conn.close()
    return json.dumps("Se ha aniadido el Departamento correctamente")
