import connexion
from swagger_server.models.pas import Pas
from datetime import date, datetime
from typing import List, Dict
from six import iteritems
from ..util import deserialize_date, deserialize_datetime
import psycopg2
import json

def busqueda_pas(idPas):
    """
    Mostar un personal en concreto
    Buscar un personal de administracion y servicios dentro de la lista del personal
    :param idPas: Identificador del Personal
    :type idPas: int

    :rtype: Pas
    """
    conn_string = "host='localhost' dbname='DepartamentoPas' user='ISA' password='1234'"
    
    # get a connection, if a connect cannot be made an exception will be raised here
    conn = psycopg2.connect(conn_string)
    
    # conn.cursor will return a cursor object, you can use this cursor to perform queries
    cursor = conn.cursor()
    
    # execute our Query
    cursor.execute("SELECT * FROM pas WHERE \"id_pas\" = " + str(idPas) + ";")
    
    # retrieve the records from the database
    records = []
    for row in cursor:
        records.append(str(row))
    conn.close()
    return json.dumps(records)


def insertar_pas(pas):
    """
    Añadir un nuevo personal
    Insertar un nuevo personal en  la lista del personal de administracion  y servicios
    :param pas: 
    :type pas: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        pas = Pas.from_dict(connexion.request.get_json())
    
    conn_string = "host='localhost' dbname='DepartamentoPas' user='ISA' password='1234'"

    # get a connection, if a connect cannot be made an exception will be raised here
    conn = psycopg2.connect(conn_string)

    # conn.cursor will return a cursor object, you can use this cursor to perform queries
    cursor = conn.cursor()

    # execute our Query
    """cursor.execute("INSERT INTO pas VALUES (" + repr(pas.id_pas) + ",'" + pas.categoria +"','" + pas.puesto + "','" + pas.dni +"','" + pas.nombre +"','" + pas.apellidos +"','" + pas.fecha_incorporacion +"','" + pas.direccion +"','" + pas.telefono +"'," + repr(pas.id_departamento) +")")"""
    
    conn.commit()
    conn.close()
    return json.dumps("Se ha aniadido el Personal correctamente")
