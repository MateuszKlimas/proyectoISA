import connexion
from swagger_server.models.departamento_pas import DepartamentoPAS
from datetime import date, datetime
from typing import List, Dict
from six import iteritems
from ..util import deserialize_date, deserialize_datetime


def crear_departamento(departamento):
    """
    Crear un departamento
    Añadir un departamento a la lista de departamentos
    :param departamento: El departamento que se va a a añadir
    :type departamento: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        departamento = DepartamentoPAS.from_dict(connexion.request.get_json())
    return 'do some magic!'


def get_departamento(idDep):
    """
    Obtener un departamento en concreto
    Devolver un departamento a partir de su identificador
    :param idDep: Identificador del Departamento
    :type idDep: int

    :rtype: DepartamentoPAS
    """
    return 'do some magic!'
