import connexion
from swagger_server.models.pas import Pas
from datetime import date, datetime
from typing import List, Dict
from six import iteritems
from ..util import deserialize_date, deserialize_datetime


def crear_pas(pas):
    """
    Crear un personal
    Añadir un personal a la lista de personal de administración y servicios
    :param pas: El personal se va a añadir
    :type pas: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        pas = Pas.from_dict(connexion.request.get_json())
    return 'do some magic!'


def get_pas(idPas):
    """
    Obtener un Personal de Administración y Servicios en concreto
    Devolver un personal a partir de su identificador
    :param idPas: Identificador del Personal
    :type idPas: int

    :rtype: Pas
    """
    return 'do some magic!'
