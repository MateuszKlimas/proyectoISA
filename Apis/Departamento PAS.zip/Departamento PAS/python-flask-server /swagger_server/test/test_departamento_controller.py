# coding: utf-8

from __future__ import absolute_import

from swagger_server.models.departamento_pas import DepartamentoPAS
from . import BaseTestCase
from six import BytesIO
from flask import json


class TestDepartamentoController(BaseTestCase):
    """ DepartamentoController integration test stubs """

    def test_crear_departamento(self):
        """
        Test case for crear_departamento

        Crear un departamento
        """
        departamento = DepartamentoPAS()
        response = self.client.open('/Pas/departamento',
                                    method='POST',
                                    data=json.dumps(departamento),
                                    content_type='application/json')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))

    def test_get_departamento(self):
        """
        Test case for get_departamento

        Obtener un departamento en concreto
        """
        response = self.client.open('/Pas/departamento/{idDep}'.format(idDep=56),
                                    method='GET',
                                    content_type='application/json')
        self.assert200(response, "Response body is : " + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
