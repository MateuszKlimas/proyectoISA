# coding: utf-8

from __future__ import absolute_import
# import models into model package
from .asignatura import Asignatura
from .asignatura_cod_grado import AsignaturaCodGrado
from .grado import Grado
from .medio_fisico_centro import MedioFisicoCentro
from .reserva import Reserva
from .universidad import Universidad
